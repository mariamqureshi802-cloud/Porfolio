document.addEventListener("DOMContentLoaded", () => {
    const year = document.getElementById("year");
    const topBtn = document.getElementById("topBtn");
    const downloadBtn = document.getElementById("downloadBtn");

    year.textContent = new Date().getFullYear();

    window.addEventListener("scroll", () => {
        topBtn.style.display = window.scrollY > 350 ? "block" : "none";
    });

    topBtn.style.display = "none";

    topBtn.addEventListener("click", () => {
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    });

    /*
      Put your final PDF CV in this same folder and name it:
      Mariam_Qureshi_CV.pdf
      Then the Download CV button will download it.
    */
    downloadBtn.addEventListener("click", () => {
        const cvFile = "Mariam_Qureshi_CV.pdf";
        const link = document.createElement("a");
        link.href = cvFile;
        link.download = cvFile;
        link.click();
    });
});
